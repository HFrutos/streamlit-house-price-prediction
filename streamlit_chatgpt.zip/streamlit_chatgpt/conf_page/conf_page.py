import streamlit as st
from PIL import Image

# Configuración de la página

st.set_page_config(
    page_title="DSB03RT",          # Título que aparece en la pestaña del navegador
    page_icon=":panda_face:",      # Icono en la pestaña (puede ser emoji o imagen)
    layout="wide",                 # Diseño de la página (wide: ancho completo, centered: centrado)
    initial_sidebar_state="collapsed", # Estado inicial de la barra lateral (collapsed, expanded)
    menu_items={                     # Configuración del menú de la aplicación
        'Get help': 'https://docs.streamlit.io',
        'Report a bug': 'https://github.com/streamlit/streamlit/issues',
        'About': "### Streamlit App - Información\nEsta aplicación está creada con Streamlit."
    }
)

# st.set_page_config(**PAGE_CONFIG) # Configuración avanzada con un diccionario (opcional)

# Emoji: https://streamlit-emoji-shortcodes-streamlit-app-gwckff.streamlit.app/

# Función principal
def main():
    st.title("Streamlit App.")  # Título principal de la aplicación
    st.sidebar.success("Hello")  # Mensaje en la barra lateral

# Verificar si el script se está ejecutando directamente
if __name__ == "__main__":
    main()

