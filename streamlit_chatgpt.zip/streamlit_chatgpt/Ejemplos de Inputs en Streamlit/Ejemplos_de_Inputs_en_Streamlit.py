import streamlit as st
import pandas as pd

st.title("Ejemplos de Inputs en Streamlit")

# Text Input: campo para texto corto
name = st.text_input(
    label="Nombre",                  # Etiqueta visible
    max_chars=20,                   # Máximo número de caracteres permitidos
    placeholder="Tu nombre"         # Texto gris que desaparece al escribir
)
st.write(f"Nombre ingresado: {name}")

# Password Input: similar al text_input pero oculta lo que escribes
password = st.text_input(
    label="Contraseña",
    max_chars=20,
    placeholder="Tu contraseña",
    type="password"                 # Oculta texto por seguridad
)
st.write(f"Contraseña ingresada (oculta): {'*' * len(password)}")

# Text Area: campo para texto largo (multilínea)
texto = st.text_area(
    label="Ingrese un comentario",
    height=150,
    max_chars=2000,
    placeholder="Escribe aquí tu reseña o comentario"
)
st.write(f"Texto ingresado:\n{texto}")

# Number Input: para números enteros o decimales con restricciones
number = st.number_input(
    label="Ingrese un número",
    min_value=-256,
    max_value=255,
    value=0,           # Valor por defecto
    step=10            # Paso de incremento/decremento
)
st.write(f"Número ingresado: {number}")

# Date Input: seleccionar una fecha
fecha = st.date_input(
    label="Selecciona una fecha para tu tutoría"
)
st.write(f"Fecha seleccionada: {fecha}")

# Time Input: seleccionar una hora
tiempo = st.time_input(
    label="Selecciona la hora"
)
st.write(f"Hora seleccionada: {tiempo}")

# Color Picker: seleccionar un color
color = st.color_picker(
    label="Selecciona un color"
)
st.write(f"Color seleccionado: {color}")
