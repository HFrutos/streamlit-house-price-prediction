import streamlit as st
import plotly.express as px
import requests
from datetime import datetime
import pandas as pd

# Lista de monedas soportadas
currencies = [
    "USD - United States Dollar",
    "GBP - British Pound",
    "JPY - Japanese Yen",
    "CHF - Swiss Franc",
    "AUD - Australian Dollar",
    "CAD - Canadian Dollar",
    "BRL - Brazilian Real",
    "CNY - Chinese Yuan",
    "MXN - Mexican Peso"
]

# Función que llama a la API de Frankfurter y devuelve un DataFrame
def currency_evolution(currency: str, year: int) -> pd.DataFrame:
    start_date = f"{year}-01-01"
    end_date = f"{year}-12-31"
    url = f"https://api.frankfurter.app/{start_date}..{end_date}?from=EUR&to={currency}"

    response = requests.get(url)
    if response.status_code != 200:
        st.error("Error fetching data from Frankfurter API.")
        return pd.DataFrame()

    data = response.json()
    rates = data["rates"]

    df = pd.DataFrame(rates).T  # Transponer
    df.reset_index(inplace=True)
    df.rename(columns={"index": "date", currency: "currency"}, inplace=True)
    df["date"] = pd.to_datetime(df["date"])
    return df[["date", "currency"]]

# App principal
def main():
    st.title("Frankfurter API App 📈")
    st.markdown("""
    Esta aplicación usa la [Frankfurter API](https://www.frankfurter.app) para visualizar cómo ha evolucionado el **Euro (EUR)**
    frente a otra moneda durante un año específico.
    """)

    # Selección de moneda y año
    currency_label = st.selectbox("Selecciona la moneda destino", currencies)
    currency = currency_label.split(" - ")[0]

    year = st.slider("Selecciona el año",
                     min_value=2015,
                     max_value=datetime.now().year,
                     value=datetime.now().year - 1)

    # Llamar a la API
    df = currency_evolution(currency, year)
    if df.empty:
        return

    df.rename(columns={"currency": currency}, inplace=True)

    with st.expander("Ver tabla de datos"):
        st.dataframe(df)

    # Extraer mes para color
    df["month"] = df["date"].dt.strftime("%B")

    # Gráfico de línea con estadísticas
    line_fig = px.line(df, x="date", y=currency, title=f"Relación EUR - {currency}")
    line_fig.add_hline(y=df[currency].mean(), line_dash="dash", line_color="blue",
                       annotation_text=f"Media: {df[currency].mean():.2f}")
    line_fig.add_hline(y=df[currency].median(), line_dash="dash", line_color="yellow",
                       annotation_text=f"Mediana: {df[currency].median():.2f}")
    line_fig.add_hline(y=df[currency].max(), line_dash="dash", line_color="green",
                       annotation_text=f"Máximo: {df[currency].max():.2f}")
    line_fig.add_hline(y=df[currency].min(), line_dash="dash", line_color="red",
                       annotation_text=f"Mínimo: {df[currency].min():.2f}")
    
    hist_fig = px.histogram(df, x=currency, nbins=50, opacity=0.8, title="Histograma de tasas")
    box_fig = px.box(df, x=currency, title="Boxplot de tasas")

    st.plotly_chart(line_fig)
    st.plotly_chart(hist_fig)
    st.plotly_chart(box_fig)

    # Gráficos coloreados por mes
    st.subheader("Visualizaciones por mes")
    line_fig2 = px.line(df, x="date", y=currency, color="month", title="Relación por mes")
    hist_fig2 = px.histogram(df, x=currency, color="month", nbins=50, opacity=0.8)
    box_fig2 = px.box(df, x=currency, color="month")

    st.plotly_chart(line_fig2)
    st.plotly_chart(hist_fig2)
    st.plotly_chart(box_fig2)

# Ejecutar
if __name__ == "__main__":
    main()
