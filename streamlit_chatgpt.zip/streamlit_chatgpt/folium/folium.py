import streamlit as st
import pandas as pd
import folium
from streamlit_folium import st_folium

# Supongamos que esta función simula obtener datos del clima
# En la práctica la puedes reemplazar por la que llames a la API real o tu módulo
def get_weather_data():
    # Creamos un DataFrame de ejemplo con ciudades en España
    data = {
        'city': ['Madrid', 'Barcelona', 'Valencia'],
        'lat': [40.4168, 41.3851, 39.4699],
        'lon': [-3.7038, 2.1734, -0.3763],
        'temperature': [25, 22, 28],
        'weather_description': ['Sunny', 'Cloudy', 'Rainy']
    }
    df = pd.DataFrame(data)
    return df

@st.cache_data  # Para cachear la función y no recargar datos cada vez
def load_data():
    return get_weather_data()

def main():
    # Configuramos la página
    st.set_page_config(
        page_title="Spain Weather - Streamlit",
        page_icon=":cloud:",
        layout="centered"
    )

    # Título y descripción
    st.title("OpenWeatherAPI & Streamlit :face_in_clouds:")
    st.markdown("Spain's current weather by capital.")

    # Cargar datos
    df = load_data()

    # Selector de ciudad
    city = st.selectbox("Select city:", df['city'].unique())

    # Filtrar datos por ciudad seleccionada
    weather_city = df[df['city'] == city]

    # Mostrar datos en tabla
    st.write(f"Weather data for {city}:")
    st.dataframe(weather_city)

    # Crear mapa centrado en España
    m = folium.Map(location=[40.4168, -3.7038], zoom_start=6)

    # Añadir marcador para la ciudad seleccionada con descripción del clima
    for _, row in weather_city.iterrows():
        folium.Marker(
            location=[row['lat'], row['lon']],
            popup=f"{row['city']}: {row['weather_description']}, {row['temperature']}°C"
        ).add_to(m)

    # Mostrar el mapa en Streamlit
    st_folium(m, width=700, height=500)

if __name__ == "__main__":
    main()
