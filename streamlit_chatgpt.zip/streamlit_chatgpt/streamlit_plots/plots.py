import seaborn as sns
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt


# Configuración de la página
st.set_page_config(
    page_title="DSB03RT - Visualización de Datos",
    page_icon=":panda_face:",
    layout="wide",
    initial_sidebar_state="collapsed"
)

def main():

    st.title("Visualización Interactiva de Datos con Streamlit")

    # Cargar dataset desde CSV
    df = pd.read_csv('tips_dataset.csv')

    # Mostrar el DataFrame
    with st.expander(label="DataFrame - Tips", expanded=False):
        st.dataframe(df)

    # Gráfico 1 - Scatterplot
    st.subheader("Gráfica: Total Bill vs Tip")
    fig, ax = plt.subplots()
    ax.scatter(x=df["total_bill"], y=df["tip"], color='blue')
    ax.set_title("Total Bill vs Tip")
    ax.set_xlabel("Total Bill")
    ax.set_ylabel("Tip")
    st.pyplot(fig)

    # Gráfico 2 - Countplot
    st.subheader("Gráfica: Conteo por Sexo")
    fig = plt.figure()
    sns.countplot(x=df["sex"], palette="viridis")
    st.pyplot(fig)

    # Gráfico 3 - Scatterplot con Hue
    st.subheader("Gráfica: Scatterplot con HUE (Fumador)")
    fig = plt.figure()
    sns.scatterplot(x=df["total_bill"], y=df["tip"], hue=df["smoker"], alpha=0.5)
    st.pyplot(fig)

    # Gráfico 4 - Boxplot
    st.subheader("Gráfica: Boxplot de Propinas por Día y Fumador")
    fig = plt.figure()
    sns.boxplot(x=df["day"], y=df["tip"], hue=df["smoker"], palette="cool")
    st.pyplot(fig)

    # Gráfica 5 - Subplots
    st.subheader("Gráfica: Subplots Interactivos")
    fig, ax = plt.subplots(nrows=2, ncols=2, figsize=(12, 8))
    sns.histplot(x=df["total_bill"], kde=True, ax=ax[0, 0], color="teal")
    sns.countplot(x=df["size"], ax=ax[0, 1], palette="magma")
    sns.scatterplot(x=df["tip"], y=df["size"], hue=df["smoker"], ax=ax[1, 0])
    sns.boxplot(x=df["time"], y=df["total_bill"], ax=ax[1, 1], palette="Blues")
    plt.tight_layout()
    st.pyplot(fig)

if __name__ == "__main__":
    main()
cd 