# app.py

# app.py

import streamlit as st
import pandas as pd
import re
import ast
from textblob import TextBlob
import plotly.express as px
from PIL import Image
import base64

# CONFIGURACIÓN DE PÁGINA
st.set_page_config(page_title="The Office EDA - Streamlit", page_icon=":coffee:", layout="centered")

# DESCARGAR ARCHIVO COMO HTML
def download_file(df: pd.DataFrame, ep_number: str) -> str:
    csv = df.to_csv(index=False)
    b64 = base64.b64encode(csv.encode()).decode()
    href = f'<a href="data:file/csv;base64,{b64}" download="episode_{ep_number}_analysis.csv">📥 Download this episode\'s data as CSV</a>'
    return href

# FUNCIÓN PRINCIPAL
def main():
    st.title("The Office EDA :coffee:")

    # Imagen
    image = Image.open("C:\Users\morgo\Desktop\curso data scientist\07-streamlit-main\07-streamlit-main\streamlit\sources\dunder_mifflin_logo.jpg")
    st.image(image=image, use_column_width=True)

    # Carga de datos
    df = pd.read_csv("sources/the_office_script.csv")
    df = df.iloc[:, 1:]
    df["season"] = df["episode"].apply(lambda x: int(x[:2]))
    df["ep_number"] = df["episode"].apply(lambda x: int(x[3:5]))
    df = df[df["ep_number"] != 99]
    df["script"] = df["script"].apply(lambda x: list(ast.literal_eval(x)))

    with st.expander("DataFrame", expanded=False):
        st.dataframe(df)
        st.write(f"DataFrame dimensions: {df.shape[0]}x{df.shape[1]}")

    # Sidebar de selección
    st.sidebar.markdown("### Select an episode of this amazing series to have a look on the script's insights.")
    season = st.sidebar.selectbox("Select season:", options=sorted(df["season"].unique()), index=0)
    ep_number = st.sidebar.selectbox("Select episode:",
                                     options=df[df["season"] == season]["episode"].values,
                                     index=0)

    # Filtrado y limpieza
    df_sidebar = df[df["episode"] == ep_number][["script"]]
    df_sidebar = df_sidebar.explode("script")
    df_sidebar["character"] = df_sidebar["script"].apply(lambda x: x.split(":")[0])
    df_sidebar = df_sidebar[~df_sidebar["character"].isin(["(adsbygoogle = window.adsbygoogle || []).push({});",
                                                           "\n\n(adsbygoogle = window.adsbygoogle || []).push({});"])]
    df_sidebar["script"] = df_sidebar["script"].apply(lambda x: re.sub("[\(\[].*?[\)\]]", "", x))
    df_sidebar["character"] = df_sidebar["character"].apply(lambda x: re.sub("[\(\[].*?[\)\]]", "", x))
    df_sidebar = df_sidebar[~df_sidebar["character"].isin(["", "All"])]
    df_sidebar["total_words"] = df_sidebar["script"].apply(lambda x: len(x.split()))
    df_sidebar["total_words"] -= df_sidebar["character"].apply(lambda x: len(x.split()))

    # Mostrar guion
    with st.expander(f"{ep_number} Script", expanded=False):
        for row in df_sidebar["script"].values:
            st.write(row)
            st.write("-" * 10)
        st.balloons()

    # Descargar archivo
    st.markdown(download_file(df_sidebar, ep_number), unsafe_allow_html=True)

    # Análisis de sentimientos
    pol = lambda x: TextBlob(x).sentiment.polarity
    sub = lambda x: TextBlob(x).sentiment.subjectivity
    df_sidebar["polarity"] = df_sidebar["script"].apply(pol)
    df_sidebar["subjectivity"] = df_sidebar["script"].apply(sub)
    df_sidebar.reset_index(drop=True, inplace=True)

    # Agrupación
    agg_func = {
        "total_words": ["count", "sum"],
        "polarity": ["mean"],
        "subjectivity": ["mean"]
    }

    df_group = df_sidebar.groupby("character", as_index=False).agg(agg_func)
    df_group.columns = ["character", "total_lines", "total_words", "polarity", "subjectivity"]
    df_group["words_per_line"] = df_group["total_words"] / df_group["total_lines"]

    # Gráficos
    fig_scatter = px.scatter(df_group, x="polarity", y="subjectivity",
                             color="character", size="total_words",
                             title="Polarity vs Subjectivity")

    fig_bar1 = px.bar(df_group, x="character", y="total_words", color="character",
                      title="Total Words - Character", text_auto=True)
    fig_bar1.update_xaxes(title_text="Characters", categoryorder="total descending")
    fig_bar1.update_yaxes(title_text="Total Words")

    fig_bar2 = px.bar(df_group, x="character", y="total_lines", color="character",
                      title="Total Lines - Character", text_auto=True)
    fig_bar2.update_xaxes(title_text="Characters", categoryorder="total descending")
    fig_bar2.update_yaxes(title_text="Total Lines")

    fig_pie = px.pie(df_group, values="words_per_line", names="character",
                     title="Words per Line - Character")
    fig_pie.update_traces(textposition="inside", textinfo="percent+label")

    fig_line = px.line(df_sidebar, y="polarity", title="Episode's Polarity")
    fig_line.update_xaxes(title_text="", showticklabels=False)

    # Mostrar gráficos
    st.plotly_chart(fig_scatter)
    st.plotly_chart(fig_bar1)
    st.plotly_chart(fig_bar2)
    st.plotly_chart(fig_pie)
    st.plotly_chart(fig_line)

# Ejecutar app
if __name__ == "__main__":
    main()
