
#he pedido esto a chatGpt "con streamlit desde visual estudio,
#  enséname lo que puedo hacer con imágenes y cómo hago para que estas
#  imágenes se modifiquen poniendo botones en la web"

import streamlit as st
from PIL import Image, ImageFilter, ImageOps
import pandas as pd

# Título del dashboard
st.title('Aplicación Interactiva con Imágenes y Datos')

# Cargar imagen original
image = Image.open('example_image.jpg')

# Mostrar imagen original
st.subheader('Imagen Original')
st.image(image, use_column_width=True)

# Controles de imagen
st.sidebar.header('Controles de Imagen')

# Opciones para modificar la imagen
gray = st.sidebar.checkbox('Escala de grises')
invert = st.sidebar.checkbox('Invertir colores')
rotation = st.sidebar.slider('Rotar Imagen (grados)', 0, 360, 0)
width = st.sidebar.slider('Ancho (px)', 50, 800, image.width)
height = st.sidebar.slider('Alto (px)', 50, 800, image.height)

# Botones para filtros
apply_blur = st.sidebar.button('Aplicar Desenfoque')
apply_contour = st.sidebar.button('Aplicar Contorno')
apply_detail = st.sidebar.button('Aplicar Detalle')
apply_edges = st.sidebar.button('Aplicar Borde')

# Crear copia para modificar
img = image.copy()

# Aplicar transformaciones
if gray:
    img = img.convert('L')

if invert:
    if img.mode == 'RGBA':
        r, g, b, a = img.split()
        rgb_image = Image.merge("RGB", (r, g, b))
        inverted_image = ImageOps.invert(rgb_image)
        img = Image.merge("RGBA", (*inverted_image.split(), a))
    elif img.mode in ['RGB', 'L']:
        img = ImageOps.invert(img)

if rotation != 0:
    img = img.rotate(rotation, expand=True)

img = img.resize((width, height))

if apply_blur:
    img = img.filter(ImageFilter.BLUR)
if apply_contour:
    img = img.filter(ImageFilter.CONTOUR)
if apply_detail:
    img = img.filter(ImageFilter.DETAIL)
if apply_edges:
    img = img.filter(ImageFilter.FIND_EDGES)

# Mostrar imagen modificada
st.subheader('Imagen Modificada')
st.image(img, use_column_width=True)
